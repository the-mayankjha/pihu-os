from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Literal

SegmentLanguage = Literal["hi", "en"]


class SpeechNormalizer:
    """Converts known Roman-Hindi/Hinglish into speech-friendly segments.

    Known Roman-Hindi words become Devanagari. Recognized English terms remain
    English so the caller can send them to an English Kokoro pipeline. Unknown
    words are preserved rather than guessed, preventing destructive transliteration.
    """

    TOKEN_RE = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)?|[\u0900-\u097F]+|[0-9]+|[^\w\s]", re.UNICODE)

    def __init__(self, data_dir: str | Path | None = None):
        self.data_dir = Path(data_dir) if data_dir else Path(__file__).parent
        self.roman = self._load("roman_hindi.json")
        self.phrases = self._load("phrases.json")
        self.english = self._load("english_terms.json")
        self.english_terms = {x.casefold() for x in self.english["preserve"]}
        self.phrase_keys = sorted(self.phrases, key=len, reverse=True)

    def _load(self, name):
        with (self.data_dir / name).open(encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def _append_segment(out, lang, text):
        text = text.strip()
        if not text:
            return
        if out and out[-1]["language"] == lang:
            out[-1]["text"] += " " + text
        else:
            out.append({"language": lang, "text": text})

    def normalize(self, text: str) -> list[dict[str, str]]:
        """Return ordered {'language': 'hi'|'en', 'text': ...} speech segments."""
        if not text or not text.strip():
            return []

        # Replace known multiword Hindi phrases first, case-insensitively.
        work = text
        for source in self.phrase_keys:
            work = re.sub(
                rf"(?<!\w){re.escape(source)}(?!\w)",
                self.phrases[source],
                work,
                flags=re.IGNORECASE,
            )

        tokens = self.TOKEN_RE.findall(work)
        out: list[dict[str, str]] = []
        for token in tokens:
            if re.fullmatch(r"[^\w\s]", token):
                if out:
                    out[-1]["text"] += token
                continue

            if re.fullmatch(r"[\u0900-\u097F]+", token):
                self._append_segment(out, "hi", token)
                continue

            if token.isdigit():
                self._append_segment(out, "en", token)
                continue

            key = token.casefold()
            if key in self.roman:
                self._append_segment(out, "hi", self.roman[key])
            elif key in self.english_terms or token[0].isupper():
                self._append_segment(out, "en", token)
            else:
                # Safe fallback: leave unknown words as English instead of
                # producing a potentially incorrect Devanagari pronunciation.
                self._append_segment(out, "en", token)

        return self._join_punctuation_spacing(out)

    @staticmethod
    def _join_punctuation_spacing(segments):
        # Keep punctuation attached and clean spaces before punctuation.
        for segment in segments:
            segment["text"] = re.sub(r"\s+([,.;:!?।])", r"\1", segment["text"]).strip()
        return [s for s in segments if s["text"]]

    def to_debug_text(self, text: str) -> str:
        """Readable preview showing which script/language each segment uses."""
        return " | ".join(
            f"[{s['language']}] {s['text']}" for s in self.normalize(text)
        )
