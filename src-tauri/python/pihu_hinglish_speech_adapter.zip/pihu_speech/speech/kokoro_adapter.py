from __future__ import annotations

import numpy as np
from kokoro import KPipeline

from .normalizer import SpeechNormalizer


class KokoroSpeech:
    """Mixed-language Kokoro playback: Hindi segments use Hindi voice;
    English segments use English voice. Audio is played, not saved.
    """

    def __init__(
        self,
        hindi_voice: str = "hf_alpha",
        english_voice: str = "af_heart",
        sample_rate: int = 24000,
        speed: float = 1.0,
    ):
        self.normalizer = SpeechNormalizer()
        self.hindi = KPipeline(lang_code="h")
        self.english = KPipeline(lang_code="a")
        self.hindi_voice = hindi_voice
        self.english_voice = english_voice
        self.sample_rate = sample_rate
        self.speed = speed

    def synthesize(self, text: str) -> np.ndarray:
        chunks = []
        for segment in self.normalizer.normalize(text):
            pipeline = self.hindi if segment["language"] == "hi" else self.english
            voice = self.hindi_voice if segment["language"] == "hi" else self.english_voice

            for _, _, audio in pipeline(segment["text"], voice=voice, speed=self.speed):
                chunks.append(np.asarray(audio, dtype=np.float32))

            # Small pause between language segments.
            chunks.append(np.zeros(int(self.sample_rate * 0.12), dtype=np.float32))

        if not chunks:
            return np.array([], dtype=np.float32)
        return np.concatenate(chunks)

    def speak(self, text: str):
        import sounddevice as sd
        audio = self.synthesize(text)
        if audio.size:
            sd.play(audio, samplerate=self.sample_rate)
            sd.wait()
